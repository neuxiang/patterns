package test;

public class User extends BaseAdt{

	String name;
	int age;
	boolean marital;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isMarital() {
		return marital;
	}
	public void setMarital(boolean marital) {
		this.marital = marital;
	}
	
	
	
}
