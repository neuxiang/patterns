package test;

public class BaseAdt {

}
